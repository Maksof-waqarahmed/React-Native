import { View, Text } from 'react-native';

export default function RideHistoryDetail(){
    return(
        <View>
            <Text>Ride History Detail</Text>
        </View>

    ) 

}